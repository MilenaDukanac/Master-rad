iex(3)>lista ++ [d: 4]
[a: 1, b: 2, c: 3, d: 4]
iex(4)>[a: 0] ++ lista
[a: 0, a: 1, b: 2, c: 3]
