iex(1)>1 and true
** (BadBooleanError) expected a boolean on left-side of "and",
 got: 1
