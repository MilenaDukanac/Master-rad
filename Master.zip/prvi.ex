iex(1)>[1, 2, true, 3]
[1, 2, true, 3]
iex(2)>length([1, 2, true, 3])
4
