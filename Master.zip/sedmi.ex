iex(1)>{:ok, "hello", 1}
{:ok, "hello", 1}
iex(2)>tuple_size({:ok, "hello", 1})
3
