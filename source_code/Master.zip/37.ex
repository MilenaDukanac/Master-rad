number < atom < reference < function < port < pid < tuple
< map < list < bitstring
