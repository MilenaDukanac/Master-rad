iex(1)> mapa = %{:a => 1, 2 => :b}
%{:a => 1, 2 => :b}
iex(2)>mapa[:a]
1
iex(3)>mapa[2]
:b
iex(4)>mapa[:c]
nil
