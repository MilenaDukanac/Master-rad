C:\Windows\system32>iex print_args.ex
Interactive Elixir (1.8.0) - press Ctrl+C to exit (type h() for help)
iex(1)>Example.print_args("Hello", "world")
Hello world
:ok
