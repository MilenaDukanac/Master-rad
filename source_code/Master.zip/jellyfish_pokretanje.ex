C:\elixir>iex jellyfish.ex
Interactive Elixir (1.8.0) - press Ctrl+C to exit (type h() ENTER for help)
iex(1)>JellyFish.jellyfish_algorithm(["AC", "CG", "AC", "GT", "CA", "GG", "AC","GT"], 0.7)
{%{
  0 => "",
  1 => "",
  2 => "",
  3 => "CG",
  4 => "CA",
  5 => "",
  6 => "",
  7 => "GG",
  8 => "",
  9 => "GT",
  10 => "AC",
  11 => ""
},
%{
  0 => 0,
  1 => 0,
  2 => 0,
  3 => 1,
  4 => 1,
  5 => 0,
  6 => 0,
  7 => 1,
  8 => 0,
  9 => 2,
  10 => 3,
  11 => 0
}}
