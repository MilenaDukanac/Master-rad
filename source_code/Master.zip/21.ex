iex(1)>users = [john: %{name: "John", age: 27, languages:
["Erlang", "Ruby", "Elixir"]}, mary: %{name: "Mary", age: 29,
languages: ["Elixir", "F#", "Clojure"]}]
[
  john:%{age:27,languages:["Erlang","Ruby","Elixir"],name:"John"},
  mary:%{age:29,languages:["Elixir","F#","Clojure"],name:"Mary"}
]
