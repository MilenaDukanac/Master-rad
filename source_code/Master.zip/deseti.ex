iex(1)>File.read("C:\elixir\text_document.txt")
{:ok, "Hello, world!"}
