iex(1)true and true
true
iex(2)>false or is_atom(:example)
true
