defmodule Example do
  def print_args(arg1, arg2) do
    IO.puts(arg1 <> " " <> arg2)
  end
end
