%{
  "AA" => ["AT"],
  "AT" => ["TG", "TG", "TG"],
  "CA" => ["AT"],
  "CC" => ["CA"],
  "GA" => ["AT"],
  "GC" => ["CC"],
  "GG" => ["GG", "GA"],
  "GT" => ["TT"],
  "TA" => ["AA"],
  "TG" => ["GC", "GG", "GT"],
  "TT" => []
}
