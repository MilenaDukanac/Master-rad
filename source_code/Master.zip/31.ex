iex(1)>lista = ["Milan Stamenkovic", "Petar Jovanovic",
"Milica Lazarevic", "Lena Markovic"]
["Milan Stamenkovic", "Petar Jovanovic", "Milica Lazarevic",
 "Lena Markovic"]
