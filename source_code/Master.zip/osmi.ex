iex(1)>tuple = {:ok, "hello", 1}
{:ok, "hello", 1}
iex(2)>elem(tuple, 1)
"hello"
