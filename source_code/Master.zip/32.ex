iex(2)>[prvi, drugi, treci | ostali] = lista
["Milan Stamenkovic", "Petar Jovanovic", "Milica Lazarevic",
 "Lena Markovic"]
