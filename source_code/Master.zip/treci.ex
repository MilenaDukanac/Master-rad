iex(1)> lista = [1, 2, 3, 4]
[1, 2, 3, 4]
iex(2)>hd(lista)
1
iex(3)>tl(lista)
[2, 3, 4]
