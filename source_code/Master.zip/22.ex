iex(2)>users[:john].age
27
