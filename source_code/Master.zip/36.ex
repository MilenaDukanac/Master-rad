#Alias modula tako da se može pozvati sa Adding umesto sa Math.Adding
alias Math.Adding, as: Adding

#Obezbeđuje da je modul kompajliran i dostupan (obično za makroe)
require Math

#Uključuje prilagođen kod definisan u Math kao proširenje
use Math
