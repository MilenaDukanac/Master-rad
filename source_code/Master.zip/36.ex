#Alias modula tako da se moze pozvati sa Adding umesto sa
#Math.Adding
alias Math.Adding, as: Adding

#Obezbedjuje da je modul kompajliran i dostupan (obicno za makroe)
require Math

#Ukljucuje prilagodjen kod definisan u Math kao prosirenje
use Math
