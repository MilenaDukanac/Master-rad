iex(1)> mapa = %{a: 1, b: 2}
%{a: 1, b: 2}
