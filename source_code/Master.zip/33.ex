iex(3)>prvi
"Milan Stamenkovic"
iex(2)>drugi
"Petar Jovanovic"
iex(3)>treci
"Milica Lazarevic"
iex(4)>ostali
["Lena Markovic"]
