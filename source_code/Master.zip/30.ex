iex(1)>"pas" = = "pas"
"pas"
