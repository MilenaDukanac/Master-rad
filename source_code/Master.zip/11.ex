iex(1)> lista = [{:a, 1}, {:b, 2}, {:c, 3}]
[a: 1, b: 2, c: 3]
iex(2)> lista = = [a: 1, b: 2, c: 3]
true
