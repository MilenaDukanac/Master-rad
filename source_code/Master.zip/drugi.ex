iex(1)>[1, 2, 3] ++ [4, 5, 6]
[1, 2, 3, 4, 5, 6]
iex(2)>[1, false, 2, true, 3, false]  - - [true, false]
[1, 2, 3, false]
