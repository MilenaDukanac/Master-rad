iex(1)>1 || true
1
iex(2)>false || 11
11
iex(3)>nil && 13
nil
iex(4)true && 17
17
iex(5)>!true
false
iex(6)!1
false
iex(7)>!nil
true
