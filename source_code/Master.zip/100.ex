def symbol_to_number(c) do
  mapa = %{"A" => "00", "T" => "01", "C" => "10", "G" => "11"}
  mapa[c]
end
