Microsoft Windows [Version 6.1.7601]
Copyright (c) 2009 Microsoft Corporation. All rights reserved.

C:\Windows\system32>iex
Interactive Elixir (1.8.0) - press Ctrl+C to exit (type h() for help)
iex(1)> 2 + 2
4
